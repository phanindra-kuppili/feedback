package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entities.Feedback;
import com.example.demo.exception.FeedbackException;
import com.example.demo.exception.MobileException;
import com.example.demo.repository.IMobileRepository;
import com.example.demo.service.FeedbackServiceImpl;
import com.example.demo.service.IFeedbackService;

@SpringBootTest
class OnlineMobileShoppingApplicationTests {
	@Autowired
	private IFeedbackService feedbackservice ;
	@Autowired
	private IMobileRepository mobileRepo;
	
	@Autowired
	private FeedbackServiceImpl feedbackService ;
//	@Test
//	void contextLoads() {
//	}

//	@Test
//	public void addMobileToCartTest() {
//		CartDTO cartDTO = new CartDTO("3463594774646879947888393", "3429392027");
//		Cart newCart=null;
//		try {
//			newCart = this.cartservice.addMobileToCart(cartDTO);
//		} catch (CustomerException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (MobileException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		assertNotNull(newCart);
//	}
	
//	@Test
//	public void addFeedbackTest() {
//	
//		Feedback feedback = new Feedback("46566483588", "testform", null , "57867446", "test", "tes@gmail.com");
//		Feedback newFeedback = null;
//		try {
//			 newFeedback = this.feedbackservice.addFeedback(feedback);
//		} catch (FeedbackException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (MobileException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	     assertNotEquals(null, newFeedback.getFeedbackId());
//	
//	}
//	

}

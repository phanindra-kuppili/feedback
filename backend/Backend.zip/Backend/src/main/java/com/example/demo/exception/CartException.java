package com.example.demo.exception;

public class CartException extends Exception {
	public CartException(String message) {
		super(message);
	}
}

package com.example.demo.exception;

public class FeedbackException extends Exception {
	public FeedbackException(String message) {
		super(message);
}
}

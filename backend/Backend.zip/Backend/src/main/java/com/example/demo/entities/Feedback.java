package com.example.demo.entities;

import java.util.Date;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Document
public class Feedback {
	@Id
	@Size(min = 3, max = 25, message = "Rating Id should be min of 3 chars & max of 25 chars.")
	@Pattern(regexp = "[0-9]+", message = "Rating Id should be Numeric, No space allowed.")
	private String feedbackId;
	@NotBlank(message = "feedback can't be Blank.")
	private String form;
	private Date DateTime;
	@NotBlank(message = "mobileId can't be Blank.")
	private String mobileId;
	@NotBlank(message = "Name can't be Blank.")
	@Pattern(regexp="[A-Za-z]+",message = "customerName should be Alphanumeric only.")
	private String customerName;
	@Email(message = "Please enter valid Email eg: yourname@ipru.com.")
	private String emailId;
	public Feedback() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public String getFeedbackId() {
		return feedbackId;
	}

	public Feedback(
		@Size(min = 3, max = 25, message = "Rating Id should be min of 3 chars & max of 25 chars.") @Pattern(regexp = "[0-9]+", message = "Rating Id should be Numeric, No space allowed.") String feedbackId,
		@NotBlank(message = "feedback can't be Blank.") String form, Date dateTime, @NotBlank(message = "mobileId can't be Blank.")String mobileId,@NotBlank(message = "Name can't be Blank.")
		@Pattern(regexp="[A-Za-z]+",message = "customerName should be Alphanumeric only.") String customerName,@Email(message = "Please enter valid Email eg: yourname@ipru.com.") String emailId) {
	super();
	this.feedbackId = feedbackId;
	this.form = form;
	DateTime = dateTime;
	this.mobileId = mobileId;
	this.customerName = customerName;
	this.emailId = emailId;
}


	public void setFeedbackId(String feedbackId) {
		this.feedbackId = feedbackId;
	}


	public String getForm() {
		return form;
	}

	public void setForm(String form) {
		this.form = form;
	}
	public Date getDateTime() {
		return DateTime;
	}

	public void setDateTime(Date DateTime) {
		this.DateTime = DateTime;
	}



	public String getMobileId() {
		return mobileId;
	}


	public void setMobileId(String mobileId) {
		this.mobileId = mobileId;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
}

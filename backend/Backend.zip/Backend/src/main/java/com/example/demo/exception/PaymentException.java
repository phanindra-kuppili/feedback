package com.example.demo.exception;

public class PaymentException extends Exception{
	public PaymentException(String message) {
		super(message);
	}
}

package com.example.demo.entities;

public class CustomerIdDTO {
	String custId;

	public CustomerIdDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerIdDTO(String custId) {
		super();
		this.custId = custId;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}
	
}

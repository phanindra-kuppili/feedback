import { Outlet, Link } from "react-router-dom";

const Layout = () => {
    return (
        <>

            <nav className="navbar navbar-expand-sm bg-light justify-content-center">
                <ul className="navbar-nav">
                    
                    <li className="nav-item">
                    <Link className="nav-link" to="Feedback">Add Feedback</Link>
                    <Link className="nav-link" to="displayfeedback">Display all feedbacks</Link>
                    </li>
                </ul>
            </nav>
            <Outlet/>
        </>
    );
}
export default Layout;
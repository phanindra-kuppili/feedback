import { useEffect, useState } from "react";
import FeedbackService from "../../Services/Feedback/FeedbackService";

function DisplayAllFeedbacks() {

    const [feedbacks, setFeedbacks] = useState(
        [
            {
            "feedbackId": "",
            "form": "",
            "mobileId": "",
            "customerName": "",
            "emailId": "",
            "dateTime": ""
              }
        ]);

    const [editFeedback, setEditFeedback] = useState(
        {
            "feedbackId": "",
            "form": "",
            "mobileId": "",
            "customerName": "",
            "emailId": "",
            "dateTime": ""
        }
    );

    const [isEdit, setIsEdit] = useState(false);
    const [msg, setMsg] = useState(undefined);
    const [errorMsg, setErrorMsg] = useState(undefined);

    useEffect(() => {
        loadAllFeedbacks();
    }, []);

    // const updateFeedback = (
    //     <>
    //         <div className="editFeedback">
    //             <h3>Edit Feedback</h3>
    //             {msg && <h5>{msg}</h5>}
    //             {errorMsg && <h5>{errorMsg}</h5>}
    //             {/* {JSON.stringify(editFeedback)} */}
    //             <form onSubmit={submitHandle}>
    //                 <label>feedbackDate:</label>
    //                 <input type="text" name="feedbackDate" value={editFeedback.feedbackDate} onChange={changeHandle}></input><br />
    //                 <label>dispatchDate:</label>
    //                 <input type="text" name="dispatchDate" disabled value={editFeedback.dispatchDate} onChange={changeHandle}></input><br />
    //                 <label>Total Cost:</label>
    //                 <input type="number" name="totalCost" disabled value={editFeedback.totalCost} onChange={changeHandle}></input><br />
    //                 <input type="submit" />
    //             </form>
    //         </div>
    //     </>
    // );

    const loadAllFeedbacks = () => {
        FeedbackService.getAllFeedbacks()
            .then((response) => {
                console.log(response.data);

                setFeedbacks(response.data);
            })
            .catch((error) => { console.log(error) })
    };

    const deleteHandler = (id) => {
        console.log("Feedback delete called");
        FeedbackService.cancelFeedback(id)
            .then((response) => {
                console.log("deleted:")
                console.log(response.data);
                setMsg("Feedback got Deleted successfully !");
                setErrorMsg(undefined);
                loadAllFeedbacks();
            })
            .catch((error) => {
                console.log(error);
                setErrorMsg("Fail to Delete Feedback !");
                setMsg(undefined);
            })
    }

    const submitHandle = (e) => {

        console.log(editFeedback);
        FeedbackService.updateFeedback(editFeedback)
            .then((response) => {
                console.log(response.data);
                setMsg("Feedback Edited successfully !");
                setErrorMsg(undefined);
                setIsEdit(false);
                loadAllFeedbacks();

            })
            .catch((error) => {
                console.log(error.response);
                setErrorMsg("Failed to Edit Profile !");
                setMsg(undefined);
                setIsEdit(false);
            })
    };

    const updateHandler = (feedback) => {
        console.log("updating" + JSON.stringify(feedback));
        setEditFeedback(feedback);
        setIsEdit(true);
    };

    const changeHandle = (e) => {
        const value = e.target.value;
        const name = e.target.name;
        setEditFeedback(prevData => ({ ...prevData, [name]: value }));
        //console.log(value);
    };
    const updateFeedback = (
        <>
            <div className="editFeedback">
                <h3>Edit Feedback:</h3>
                <form onSubmit={submitHandle}>
                    <label>Feedback ID:</label>
                    <input type="text" name="feedbackId" value={editFeedback.feedbackId} onChange={changeHandle}></input><br />
                    <label>form:</label>
                    <input type="text" name="form" value={editFeedback.form} onChange={changeHandle}></input><br />
                    {/* <label>customerEmailId:</label>
                    <input type="text" name="customerEmailId" value={editFeedback.customerEmailId} onChange={changeHandle}></input><br /> */}
                    <label>mobileId:</label>
                    <input type="text" name="mobileId" value={editFeedback.mobileId} onChange={changeHandle}></input><br />
                    <label>dateTime:</label>
                    <input type="text" name="dateTime" value={editFeedback.dateTime} onChange={changeHandle}></input><br />
                    <label>customer Name:</label>
                    <input type="text" name="customerName" value={editFeedback.customerName} onChange={changeHandle}></input><br />
                    <label>customer emailId:</label>
                    <input type="text" name="emailId" value={editFeedback.emailId} onChange={changeHandle}></input><br />
                    <input type="submit" />
                </form>
            </div>
        </>
    );
    const feedbacksTableElement = (
        <>
            <div className="displayFeedbacks" >
                <h3>Display All Feedbacks:</h3>
                {msg && <h5 className="alert alert-success">{msg}</h5>}
                {errorMsg && <h5 className="alert alert-danger">{errorMsg}</h5>}
                <table className="table table-striped table-bfeedbacked">
                    <thead>
                        <tr>
                            <th>FeedbackId</th>
                            <th>Form</th>
                            <th>mobileId</th>
                            <th>dateTime</th>
                            <th>customerName</th>
                            <th>emailId</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            feedbacks.map((feedback) => (
                                <tr key={feedback.feedbackId}>
                                    <td>{feedback.feedbackId}</td>
                                    <td>{feedback.form}</td>
                                    <td>{feedback.mobileId}</td>
                                    <td>{feedback.dateTime}</td>
                                    <td>{feedback.customerName}</td>
                                    <td>{feedback.emailId}</td>
                                    <td>
                                        <input className="btn btn-info" id="edit" type="button" value="Edit Feedback" onClick={() => updateHandler(feedback)}></input>
                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                        <input className="btn btn-danger" id="delete" type="button" value="Delete Feedback" onClick={() => deleteHandler(feedback.feedbackId)}></input>
                                    </td>
                                </tr>
                            )
                            )
                        }
                    </tbody>
                </table>
            </div>
        </>
    )
    return isEdit ? updateFeedback : feedbacksTableElement
}
export default DisplayAllFeedbacks;
import { useState } from "react";
import FeedbackService from "../../Services/Feedback/FeedbackService";

function AddFeedback() {
 
    const [Feedback,setFeedback] = useState({
        
        
            "feedbackId": "",
            "form": "",
            "mobileId": "",
            "customerName": "",
            "emailId": "",
            "dateTime": ""
          
          
      });
 
      const [msg, setMsg] = useState(undefined);
      const [errorMsg, setErrorMsg] = useState(undefined);

      const handleChange = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        setFeedback((preFeedback) => ({ ...preFeedback, [name]: value }))
    };
    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(Feedback);
        FeedbackService.addFeedback(Feedback)
            .then((response) => {
                console.log(response.data)
                setMsg("Feedback Added Successfully !");
                setErrorMsg(undefined);
            })
            .catch((error) => {
                console.log(error)
                setErrorMsg("mobile id is not present !");
                setMsg(undefined);
            })
    }

    return (
 
      <>
        <div className="addFeedback">
            <h3> Create new Feedback:</h3>
            {msg && <h5 className="alert alert-success">{msg}</h5>}
            {errorMsg && <h5 className="alert alert-danger">{errorMsg}</h5>}
            <form onSubmit={handleSubmit}>
                Feedback Id:
                <input type="text" name="feedbackId" value={Feedback.feedbackId} onChange={handleChange} /><br />
                form:
                <input type="text" name="form" value={Feedback.form} onChange={handleChange} /><br />
                customer Name:
                <input type="text" name="customerName" value={Feedback.customerName} onChange={handleChange} /><br />
                customer emailId:
                <input type="text" name="emailId" value={Feedback.emailId} onChange={handleChange} /><br />
                dateTime
                <input type="text" name="dateTime" value={Feedback.dateTime} onChange={handleChange} /><br />
                mobileId
                <input type="text" name="mobileId" value={Feedback.mobileId} onChange={handleChange} /><br />
                <input type="submit" />
            </form>
            </div>
        </>
    );
};
export default  AddFeedback;
import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from './Pages/Layout';
import NoPage from './Pages/NoPage';
import AddFeedback from './Components/Feedback/AddFeedback';
import DisplayAllFeedbacks from './Components/Feedback/GetAllFeedback';

function App() {
  return (
    <>
      <h1>Welcome to Online Mobile Application </h1>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route path="Feedback" element={<AddFeedback />} />
           <Route path="displayFeedback" element={<DisplayAllFeedbacks />} />
           <Route path="*" element={<NoPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}
export default App;

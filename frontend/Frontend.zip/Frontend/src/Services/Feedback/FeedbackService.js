import http from "../Feedback/http-common";
class FeedbackService{
    getAllFeedbacks(){
         return http.get("feedbacks");
    }
    addFeedback(feedback){
        return http.post("addFeedback",feedback);
    }
    updateFeedback(editfeedback){
        return http.put("updateFeedback",editfeedback);
    }
    cancelFeedback(id){
        return http.delete("cancelFeedback/"+id);
    }
}
export default new FeedbackService();